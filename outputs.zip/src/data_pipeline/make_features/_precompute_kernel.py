import polars as pl
import numpy as np
from datetime import date
def get_PrEp():
    """
    获取核函数矩阵 (对应solution.py中的Feiyang: 1. 获得核函数 PrEp)
    """
    PrOriginalEp = np.zeros((2000, 2000))
    PrOriginalEp[1, 0] = 1
    PrOriginalEp[2, range(2)] = [0.5, 0.5]
    for i in range(3, 2000):
        scale = (i - 1) / 2.
        x = np.arange(-(i + 1) / 2. + 1, (i + 1) / 2., step=1) / scale
        y = 3. / 4. * (1 - x ** 2)
        y = y / np.sum(y)
        PrOriginalEp[i, range(i)] = y
    PrEp = PrOriginalEp.copy()
    for i in range(3, 2000):
        PrEp[i, :i] = (PrEp[i, :i] * i + 1) / (i + 1)
    return PrEp


def kernel_median(values, PrEp):
    """
    计算核函数中位数 (对应solution.py中的feat_kernelMedian函数)
    """
    if len(values) == 0:
        return 0
    
    values = np.array(values)
    x = values[~np.isnan(values)]
    n = len(x)
    if n == 0:
        return 0
    
    weight = np.repeat(1.0, n)
    idx = np.argsort(x)
    x = x[idx]
    
    if n < PrEp.shape[0]:
        pr = PrEp[n, :n]
    else:
        scale = (n - 1) / 2.
        xxx = np.arange(-(n + 1) / 2. + 1, (n + 1) / 2., step=1) / scale
        yyy = 3. / 4. * (1 - xxx ** 2)
        yyy = yyy / np.sum(yyy)
        pr = (yyy * n + 1) / (n + 1)
    
    ans = np.sum(pr * x * weight) / float(np.sum(pr * weight))
    return ans
