import polars as pl
import numpy as np
from datetime import date
from ._date_handle_func import date_handle
from ._precompute_kernel import get_PrEp, kernel_median






def feat_eng_v2(reservation_data: pl.LazyFrame, visitor_data: pl.LazyFrame, 
               air_info: pl.LazyFrame, date_info: pl.LazyFrame,
               t_begin: date = date(2017, 4, 23)) -> pl.DataFrame:
    """
    API化的特征提取函数V2版本
    
    输入表结构说明:
    reservation_data: LazyFrame - 合并后的预订数据，包含如下列:
        - air_store_id: str - AIR系统餐厅ID
        - visit_datetime: str - 访问时间 (YYYY-MM-DD HH:MM:SS格式)
        - reserve_datetime: str - 预订时间 (YYYY-MM-DD HH:MM:SS格式)
        - reserve_visitors: int - 预订访客数
        - hpg_store_id: str (可选) - HPG系统餐厅ID
    
    visitor_data: LazyFrame - 真实访客数据，包含如下列:
        - air_store_id: str - AIR系统餐厅ID
        - visit_date: str - 访问日期 (YYYY-MM-DD格式)
        - visitors: int - 实际访客数
    
    air_info: LazyFrame - AIR餐厅信息，包含如下列:
        - air_store_id: str - AIR系统餐厅ID
        - air_genre_name: str - 餐厅类型
        - air_area_name: str - 餐厅区域
        - latitude: float - 纬度
        - longitude: float - 经度
    
    date_info: LazyFrame - 日期信息，包含如下列:
        - calendar_date: str - 日期 (YYYY-MM-DD格式)
        - day_of_week: str/int - 星期几
        - holiday_flg: int - 是否为节假日 (0或1)
    
    t_begin: date - 分割日期，默认为2017-04-23
    
    输出表结构:
    DataFrame - 包含特征X和目标Y的表，以及is_air_only和is_train标记，包含约294个特征列
    """
    
    # 收集LazyFrame为DataFrame
    reservation_df = reservation_data.collect()
    visitor_df = visitor_data.collect()
    air_info_df = air_info.collect()
    date_info_df = date_info.collect()
    
    # 重命名date_info列以匹配代码中的名称
    date_info_df = date_info_df.rename({
        "calendar_date": "visit_date"
    })
    
    # 处理日期信息中的星期几
    day_mapping = {
        "Monday": 1, "Tuesday": 2, "Wednesday": 3, "Thursday": 4,
        "Friday": 5, "Saturday": 6, "Sunday": 7
    }
    
    # 如果day_of_week是字符串形式，则进行映射
    if "day_of_week" in date_info_df.columns and date_info_df["day_of_week"].dtype == pl.Utf8:
        date_info_df = date_info_df.with_columns([
            pl.col("day_of_week").replace(day_mapping).alias("day_of_week")
        ])
    
    # 添加holiday列
    date_info_df = date_info_df.with_columns(
        ((pl.col("day_of_week") >= 6) | (pl.col("holiday_flg") == 1)).cast(pl.Int8).alias("holiday")
    )
    
    # 处理预订数据，提取日期并计算预订提前天数
    reservation_df = reservation_df.with_columns([
        pl.col("visit_datetime").str.strptime(pl.Datetime, "%Y-%m-%d %H:%M:%S").alias("visit_datetime_parsed"),
        pl.col("reserve_datetime").str.strptime(pl.Datetime, "%Y-%m-%d %H:%M:%S").alias("reserve_datetime_parsed")
    ])
    
    # 提取日期部分
    reservation_df = reservation_df.with_columns([
        pl.col("visit_datetime_parsed").dt.date().alias("visit_date"),
        pl.col("reserve_datetime_parsed").dt.date().alias("reserve_date")
    ])
    
    # 计算预订提前天数
    reservation_df = reservation_df.with_columns(
        (pl.col("visit_date") - pl.col("reserve_date")).dt.total_days().alias("reserve_datetime_diff")
    )
    
    # 处理访客数据，添加day_gap列
    visitor_df = visitor_df.with_columns(
        pl.col("visit_date").str.strptime(pl.Date, "%Y-%m-%d").alias("visit_date_parsed")
    )
    
    visitor_df = visitor_df.with_columns(
        (pl.col('visit_date_parsed') - pl.lit(t_begin)).dt.total_days().alias('day_gap')
    )
    
    # 对访客数进行对数变换
    visitor_df = visitor_df.with_columns(
        pl.col("visitors").map_elements(
            lambda x: np.log1p(float(x)) if float(x) > 0 else 0,
            return_dtype=pl.Float64
        ).alias("visitors")
    )
    
    # 分离AIR和HPG预订数据
    # 假设HPG数据可以通过某种方式识别，这里我们假设air_store_id以air_开头的是AIR数据
    air_reserve_df = reservation_df.filter(pl.col("air_store_id").str.starts_with("air"))
    
    # 如果有hpg_store_id列，我们可以更准确地区分
    if "hpg_store_id" in reservation_df.columns:
        # AIR预订数据是没有hpg_store_id或者hpg_store_id为空的
        air_reserve_df = reservation_df.filter(
            pl.col("hpg_store_id").is_null() | (pl.col("hpg_store_id") == "")
        )
        # HPG预订数据是有hpg_store_id的
        hpg_reserve_df = reservation_df.filter(pl.col("hpg_store_id").is_not_null() & (pl.col("hpg_store_id") != ""))
    else:
        # 如果没有hpg_store_id列，我们假设所有数据都是AIR预订数据
        # 在实际情况中，可能需要根据其他方式区分
        hpg_reserve_df = reservation_df.filter(~pl.col("air_store_id").str.starts_with("air"))
    
    # 处理预订数据，添加day_gap列
    air_reserve_df = air_reserve_df.with_columns([
        pl.col("visit_date").str.strptime(pl.Date, "%Y-%m-%d").alias("visit_date_parsed"),
        pl.col("reserve_date").str.strptime(pl.Date, "%Y-%m-%d").alias("reserve_date_parsed")
    ])
    
    air_reserve_df = air_reserve_df.with_columns(
        (pl.col('visit_date_parsed') - pl.lit(t_begin)).dt.total_days().alias('day_gap')
    )
    
    hpg_reserve_df = hpg_reserve_df.with_columns([
        pl.col("visit_date").str.strptime(pl.Date, "%Y-%m-%d").alias("visit_date_parsed"),
        pl.col("reserve_date").str.strptime(pl.Date, "%Y-%m-%d").alias("reserve_date_parsed")
    ])
    
    hpg_reserve_df = hpg_reserve_df.with_columns(
        (pl.col('visit_date_parsed') - pl.lit(t_begin)).dt.total_days().alias('day_gap')
    )
    
    # 处理标签数据（即需要预测的数据）
    label_df = visitor_df.clone()
    
    # 处理日期特征
    label_df = date_handle_v2(label_df, air_info_df, date_info_df, t_begin)
    
    # 创建预订特征
    PrEp = get_PrEp()
    label_df = create_reservation_features_v2(label_df, air_reserve_df, hpg_reserve_df, PrEp)
    
    # 创建时间窗口特征
    label_df = create_time_window_features_v2(label_df, visitor_df, air_reserve_df, hpg_reserve_df, PrEp)
    
    # 创建历史特征
    label_df = create_historical_features_v2(label_df, visitor_df, PrEp)
    
    # 添加标记列
    label_df = label_df.with_columns([
        # is_air_only标记：默认都是AIR数据
        pl.lit(True).alias("is_air_only"),
        # is_train标记：根据日期判断是否为训练数据
        (pl.col("day_gap") < 0).alias("is_train")
    ])
    
    return label_df