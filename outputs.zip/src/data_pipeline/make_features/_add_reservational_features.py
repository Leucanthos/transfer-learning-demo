import polars as pl
from ._precompute_kernel import get_PrEp, kernel_median

def create_reservation_features(reserve_tbl:pl.LazyFrame, PrEp):
    """
    创建预订相关特征
    
    Args:
        reserve_tbl: 预订数据
        PrEp: 核函数矩阵
        
    Returns:
        带预订特征的DataFrame
    """
    # AIR预订统计特征 (对应solution.py中Feiyang: 4. 把这两段的 mean 改成了 kernelMedian)
    store_date_level_tbl = (
        reserve_tbl
        .group_by(["air_store_id", "visit_date"])
        .agg(
            pl.col("reserve_datetime_diff").sum().alias("reserve_datetime_diff_sum"),
            pl.col("reserve_datetime_diff").map_elements(
                lambda x: kernel_median(list(x), PrEp) if len(list(x)) > 0 else 0, 
                return_dtype=pl.Float64
            ).alias("air_reserve_datetime_diff_mean"),
            pl.col("reserve_visitors").sum().alias("air_reserve_visitors_sum"),
            pl.col("reserve_visitors").map_elements(
                lambda x: kernel_median(list(x), PrEp) if len(list(x)) > 0 else 0, 
                return_dtype=pl.Float64
            ).alias("air_reserve_visitors_mean")
        )
    )
    date_level_tbl = (
        reserve_tbl
        .group_by(["visit_date"])
        .agg(
            pl.col("reserve_visitors").sum().alias("air_date_reserve_visitors_sum"),
            pl.col("reserve_visitors").map_elements(
                lambda x: kernel_median(list(x), PrEp) if len(list(x)) > 0 else 0, 
                return_dtype=pl.Float64
            ).alias("air_date_reserve_visitors_mean")
        )
    )
    return (
        store_date_level_tbl
        .join(
            date_level_tbl, 
            on=["visit_date"], 
            how="left"
        )
    )