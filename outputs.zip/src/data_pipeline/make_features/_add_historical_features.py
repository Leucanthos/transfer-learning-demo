import polars as pl
from ._precompute_kernel import get_PrEp, kernel_median
from typing import List, Tuple, Callable, Any


def _create_base_historical_features(train_df: pl.LazyFrame, PrEp: List[List[float]]) -> pl.LazyFrame:
    """
    创建基础历史访问特征 (月初月中月末特征)
    
    Args:
        train_df: 训练数据
        PrEp: 核函数矩阵
        
    Returns:
        带基础历史特征的DataFrame
    """
    # 月初月中月末特征 (对应solution.py中Feiyang: 6. 把这两段的 mean 改成了 kernelMedian)
    air_day_group = train_df.group_by(["air_store_id","stage_of_month", "weekday"]).agg(
        pl.col("visitors").map_elements(
            lambda x: kernel_median(list(x), PrEp) if len(list(x)) > 0 else 0, 
            return_dtype=pl.Float64
        ).alias("air_day_mean")
    )
    
    air_holiday_group = train_df.group_by(["air_store_id", "stage_of_month", "holiday"]).agg(
        pl.col("visitors").map_elements(
            lambda x: kernel_median(list(x), PrEp) if len(list(x)) > 0 else 0, 
            return_dtype=pl.Float64
        ).alias("air_holiday_mean")
    )
    
    # 合并基础特征
    base_features = air_day_group.join(air_holiday_group, on=["air_store_id"], how="outer")
    return base_features


def _aggregate_feature(
    df: pl.LazyFrame,
    group_cols: List[str],
    agg_exprs: List[pl.Expr],
    feature_name: str
) -> pl.LazyFrame:
    """
    通用聚合特征计算函数
    
    Args:
        df: 输入数据
        group_cols: 分组列
        agg_exprs: 聚合表达式列表
        feature_name: 特征名称
        
    Returns:
        聚合后的特征
    """
    return df.group_by(group_cols).agg(agg_exprs)


def _create_statistical_features(
    df: pl.LazyFrame,
    group_cols: List[str],
    window_size: int,
    stat_type: str,
    PrEp: List[List[float]] = None
) -> pl.LazyFrame:
    """
    创建统计特征的通用函数
    
    Args:
        df: 输入数据
        group_cols: 分组列
        window_size: 时间窗口大小
        stat_type: 统计类型 ('basic', 'kernel_median')
        PrEp: 核函数矩阵 (仅在stat_type='kernel_median'时需要)
        
    Returns:
        统计特征
    """
    if stat_type == 'basic':
        return _aggregate_feature(
            df,
            group_cols,
            [
                pl.col("visitors").median().alias(f"air_median_{window_size}"),
                pl.col("visitors").mean().alias(f"air_mean_{window_size}"),
                pl.col("visitors").max().alias(f"air_max_{window_size}"),
                pl.col("visitors").min().alias(f"air_min_{window_size}"),
                pl.col("visitors").std().alias(f"air_std_{window_size}"),
                pl.col("visitors").count().alias(f"air_count_{window_size}")
            ],
            f"basic_stats_{window_size}"
        )
    elif stat_type == 'kernel_median' and PrEp is not None:
        return _aggregate_feature(
            df,
            group_cols,
            [
                pl.col("visitors").map_elements(
                    lambda x: kernel_median(list(x), PrEp) if len(list(x)) > 0 else 0, 
                    return_dtype=pl.Float64
                ).alias(f"air_kermed_{window_size}")
            ],
            f"kernel_median_{window_size}"
        )
    elif stat_type == 'weekday_based':
        return _aggregate_feature(
            df,
            group_cols,
            [
                pl.col("visitors").max().alias(f"air_week_max_{window_size}"),
                pl.col("visitors").min().alias(f"air_week_min_{window_size}"),
                pl.col("visitors").std().alias(f"air_week_std_{window_size}"),
                pl.col("visitors").count().alias(f"air_week_count_{window_size}")
            ],
            f"weekday_stats_{window_size}"
        )
    elif stat_type == 'weekday_kernel' and PrEp is not None:
        return _aggregate_feature(
            df,
            group_cols,
            [
                pl.col("visitors").map_elements(
                    lambda x: kernel_median(list(x), PrEp) if len(list(x)) > 0 else 0, 
                    return_dtype=pl.Float64
                ).alias(f"air_week_kermed_{window_size}")
            ],
            f"weekday_kernel_{window_size}"
        )
    elif stat_type == 'holiday_based':
        return _aggregate_feature(
            df,
            group_cols,
            [
                pl.col("visitors").max().alias(f"air_holiday_max_{window_size}"),
                pl.col("visitors").min().alias(f"air_holiday_min_{window_size}"),
                pl.col("visitors").count().alias(f"air_holiday_count_{window_size}")
            ],
            f"holiday_stats_{window_size}"
        )
    elif stat_type == 'holiday_kernel' and PrEp is not None:
        return _aggregate_feature(
            df,
            group_cols,
            [
                pl.col("visitors").map_elements(
                    lambda x: kernel_median(list(x), PrEp) if len(list(x)) > 0 else 0, 
                    return_dtype=pl.Float64
                ).alias(f"air_holiday_kermed_{window_size}")
            ],
            f"holiday_kernel_{window_size}"
        )
    elif stat_type == 'genre_holiday_based':
        return _aggregate_feature(
            df,
            group_cols,
            [
                pl.col("visitors").max().alias(f"air_genre_name_holiday_max_{window_size}"),
                pl.col("visitors").min().alias(f"air_genre_name_holiday_min_{window_size}"),
                pl.col("visitors").count().alias(f"air_genre_name_holiday_count_{window_size}")
            ],
            f"genre_holiday_stats_{window_size}"
        )
    elif stat_type == 'genre_holiday_kernel' and PrEp is not None:
        return _aggregate_feature(
            df,
            group_cols,
            [
                pl.col("visitors").map_elements(
                    lambda x: kernel_median(list(x), PrEp) if len(list(x)) > 0 else 0, 
                    return_dtype=pl.Float64
                ).alias(f"air_genre_name_holiday_kermed_{window_size}")
            ],
            f"genre_holiday_kernel_{window_size}"
        )
    elif stat_type == 'genre_weekday_based':
        return _aggregate_feature(
            df,
            group_cols,
            [
                pl.col("visitors").max().alias(f"air_genre_name_weekday_max_{window_size}"),
                pl.col("visitors").min().alias(f"air_genre_name_weekday_min_{window_size}"),
                pl.col("visitors").count().alias(f"air_genre_name_weekday_count_{window_size}")
            ],
            f"genre_weekday_stats_{window_size}"
        )
    elif stat_type == 'genre_weekday_kernel' and PrEp is not None:
        return _aggregate_feature(
            df,
            group_cols,
            [
                pl.col("visitors").map_elements(
                    lambda x: kernel_median(list(x), PrEp) if len(list(x)) > 0 else 0, 
                    return_dtype=pl.Float64
                ).alias(f"air_genre_name_weekday_kermed_{window_size}")
            ],
            f"genre_weekday_kernel_{window_size}"
        )
    elif stat_type == 'area_holiday_based':
        return _aggregate_feature(
            df,
            group_cols,
            [
                pl.col("visitors").max().alias(f"air_area_name_holiday_max_{window_size}"),
                pl.col("visitors").min().alias(f"air_area_name_holiday_min_{window_size}"),
                pl.col("visitors").count().alias(f"air_area_name_holiday_count_{window_size}")
            ],
            f"area_holiday_stats_{window_size}"
        )
    elif stat_type == 'area_holiday_kernel' and PrEp is not None:
        return _aggregate_feature(
            df,
            group_cols,
            [
                pl.col("visitors").map_elements(
                    lambda x: kernel_median(list(x), PrEp) if len(list(x)) > 0 else 0, 
                    return_dtype=pl.Float64
                ).alias(f"air_area_name_holiday_kermed_{window_size}")
            ],
            f"area_holiday_kernel_{window_size}"
        )
    elif stat_type == 'area_genre_holiday_based':
        return _aggregate_feature(
            df,
            group_cols,
            [
                pl.col("visitors").max().alias(f"air_area_genre_name_holiday_max_{window_size}"),
                pl.col("visitors").min().alias(f"air_area_genre_name_holiday_min_{window_size}"),
                pl.col("visitors").count().alias(f"air_area_genre_name_holiday_count_{window_size}")
            ],
            f"area_genre_holiday_stats_{window_size}"
        )
    elif stat_type == 'area_genre_holiday_kernel' and PrEp is not None:
        return _aggregate_feature(
            df,
            group_cols,
            [
                pl.col("visitors").map_elements(
                    lambda x: kernel_median(list(x), PrEp) if len(list(x)) > 0 else 0, 
                    return_dtype=pl.Float64
                ).alias(f"air_area_genre_name_holiday_kermed_{window_size}")
            ],
            f"area_genre_holiday_kernel_{window_size}"
        )
    
    # 默认返回空DataFrame
    return pl.DataFrame().lazy()


def create_historical_features_v2(
    label_df: pl.LazyFrame, 
    train_df: pl.LazyFrame, 
    PrEp: List[List[float]]
) -> pl.LazyFrame:
    """
    创建历史访问特征 (对应solution.py中for i in [21,35,63,140,280,350,420]循环)
    
    Args:
        label_df: 标签数据框
        train_df: 训练数据
        PrEp: 核函数矩阵
        
    Returns:
        带历史特征的DataFrame
    """
    # 创建基础历史特征
    base_features = _create_base_historical_features(train_df, PrEp)
    label_df = label_df.join(base_features, on=["air_store_id", "stage_of_month", "weekday", "holiday"], how="left")
    
    # 不同时间窗口的历史访问特征
    window_sizes = [21, 35, 63, 140, 280, 350, 420]
    
    for window_size in window_sizes:
        # 筛选时间窗口内的数据
        df_select = train_df.filter(pl.col('day_gap') >= -window_size)
        
        # 如果窗口内无数据，则跳过
        if len(df_select.collect()) == 0:
            continue
            
        # 创建各类特征
        # 店铺级别的基本统计特征
        store_basic_features = _create_statistical_features(df_select, ["air_store_id"], window_size, 'basic')
        store_kernel_features = _create_statistical_features(df_select, ["air_store_id"], window_size, 'kernel_median', PrEp)
        store_features = store_basic_features.join(store_kernel_features, on=["air_store_id"], how="left")
        
        # 按weekday聚合的特征
        weekday_basic_features = _create_statistical_features(df_select, ["air_store_id", "weekday"], window_size, 'weekday_based')
        weekday_kernel_features = _create_statistical_features(df_select, ["air_store_id", "weekday"], window_size, 'weekday_kernel', PrEp)
        weekday_features = weekday_basic_features.join(weekday_kernel_features, on=["air_store_id", "weekday"], how="left")
        
        # 按holiday聚合的特征
        holiday_basic_features = _create_statistical_features(df_select, ["air_store_id", "holiday"], window_size, 'holiday_based')
        holiday_kernel_features = _create_statistical_features(df_select, ["air_store_id", "holiday"], window_size, 'holiday_kernel', PrEp)
        holiday_features = holiday_basic_features.join(holiday_kernel_features, on=["air_store_id", "holiday"], how="left")
        
        # 按genre和holiday聚合的特征
        genre_holiday_basic_features = _create_statistical_features(df_select, ["air_genre_name", "holiday"], window_size, 'genre_holiday_based')
        genre_holiday_kernel_features = _create_statistical_features(df_select, ["air_genre_name", "holiday"], window_size, 'genre_holiday_kernel', PrEp)
        genre_holiday_features = genre_holiday_basic_features.join(genre_holiday_kernel_features, on=["air_genre_name", "holiday"], how="left")
        
        # 按genre和weekday聚合的特征
        genre_weekday_basic_features = _create_statistical_features(df_select, ["air_genre_name", "weekday"], window_size, 'genre_weekday_based')
        genre_weekday_kernel_features = _create_statistical_features(df_select, ["air_genre_name", "weekday"], window_size, 'genre_weekday_kernel', PrEp)
        genre_weekday_features = genre_weekday_basic_features.join(genre_weekday_kernel_features, on=["air_genre_name", "weekday"], how="left")
        
        # 按area和holiday聚合的特征
        area_holiday_basic_features = _create_statistical_features(df_select, ["air_area_name", "holiday"], window_size, 'area_holiday_based')
        area_holiday_kernel_features = _create_statistical_features(df_select, ["air_area_name", "holiday"], window_size, 'area_holiday_kernel', PrEp)
        area_holiday_features = area_holiday_basic_features.join(area_holiday_kernel_features, on=["air_area_name", "holiday"], how="left")
        
        # 按area、genre和holiday聚合的特征
        area_genre_holiday_basic_features = _create_statistical_features(df_select, ["air_area_name", "air_genre_name", "holiday"], window_size, 'area_genre_holiday_based')
        area_genre_holiday_kernel_features = _create_statistical_features(df_select, ["air_area_name", "air_genre_name", "holiday"], window_size, 'area_genre_holiday_kernel', PrEp)
        area_genre_holiday_features = area_genre_holiday_basic_features.join(area_genre_holiday_kernel_features, on=["air_area_name", "air_genre_name", "holiday"], how="left")
        
        # 合并所有特征到标签数据
        label_df = label_df.join(store_features, on=["air_store_id"], how="left")
        label_df = label_df.join(weekday_features, on=["air_store_id", "weekday"], how="left")
        label_df = label_df.join(holiday_features, on=["air_store_id", "holiday"], how="left")
        label_df = label_df.join(genre_holiday_features, on=["air_genre_name", "holiday"], how="left")
        label_df = label_df.join(genre_weekday_features, on=["air_genre_name", "weekday"], how="left")
        label_df = label_df.join(area_holiday_features, on=["air_area_name", "holiday"], how="left")
        label_df = label_df.join(area_genre_holiday_features, on=["air_area_name", "air_genre_name", "holiday"], how="left")
    
    return label_df