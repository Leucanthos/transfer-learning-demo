
import polars as pl
import numpy as np
from datetime import date
def date_handle(df, date_info, t_begin=date(2017, 4, 15)):
    """
    处理日期特征 (对应solution.py中的date_handle函数)
    
    Args:
        df: 输入DataFrame
        date_info: 日期信息
        t_begin: 分割日期
        
    Returns:
        处理后的DataFrame
    """
    # 先确保visit_date是日期类型
    if df["visit_date"].dtype == pl.Utf8:
        df = df.with_columns([
            pl.col('visit_date').str.strptime(pl.Date, "%Y-%m-%d").alias('visit_date_parsed')
        ])
    else:
        df = df.with_columns([
            pl.col('visit_date').alias('visit_date_parsed')
        ])
    
    df = df.with_columns([
        df['visit_date_parsed'].dt.weekday().alias('weekday'),
        df['visit_date_parsed'].dt.day().alias('day')
    ])
    
    # 添加day_gap列
    df = df.with_columns(
        (pl.col('visit_date_parsed') - pl.lit(t_begin)).dt.total_days().alias('day_gap')
    )
    
    # 添加days_to_side特征 (对应solution.py中Feiyang: 2. 新的特征 "days_to_side")
    days_of_months = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    df = df.with_columns(
        pl.struct(['visit_date_parsed']).map_elements(
            lambda row: min(
                row['visit_date_parsed'].day, 
                days_of_months[row['visit_date_parsed'].month-1] - row['visit_date_parsed'].day
            ),
            return_dtype=pl.Int32
        )
        .alias('days_to_side')
    )
    
    # 修改day特征 (对应solution.py中Feiyang: 3. 把月初月末的定义改成了7天)
    df = df.with_columns(
        pl.when(pl.col('day') <= 7)
        .then(0)
        .when(pl.col('day') >= 24)
        .then(2)
        .otherwise(1)
        .alias('stage_of_month')
    )
    
    # 合并餐厅信息和日期信息
    #df = df.join(air_info, on="air_store_id", how="left")
    df = df.join(date_info, left_on="visit_date", right_on="visit_date", how="left")
    
    return df