import polars as pl
from ._precompute_kernel import get_PrEp, kernel_median


def create_time_window_features_v2(
        reserve_tbl, 
        train_df, 
        air_reserve_df, 
        hpg_reserve_df, 
        PrEp
    ):
    """
    创建时间窗口特征 (对应solution.py中for i in [35,63,140]循环)
    
    Args:
        label_df: 标签数据框
        train_df: 训练数据
        air_reserve_df: AIR预订数据
        hpg_reserve_df: HPG预订数据
        PrEp: 核函数矩阵
        
    Returns:
        带时间窗口特征的DataFrame
    """
    for i in [35, 63, 140]:
        # 筛选时间窗口内的数据
        reserve_select = reserve_tbl.filter(pl.col('day_gap') >= -i)
        
        # AIR预订聚合
        if len(reserve_select) > 0:
            date_air_reserve = (
                reserve_select
                .group_by(["air_store_id", "visit_date"])
                .agg(
                    pl.col("reserve_visitors").sum().alias("reserve_visitors_sum")
                    ,pl.col("reserve_visitors").count().alias("reserve_visitors_count")
                    ,pl.col("reserve_visitors").map_elements(
                        lambda x: kernel_median(list(x), PrEp) if len(list(x)) > 0 else 0, 
                        return_dtype=pl.Float64
                    ).alias("reserve_visitors_mean")
                    ,
                )

            )
            
            
            date_air_reserve = date_handle_v2(date_air_reserve, 
                                            label_df.select(["air_store_id", "air_genre_name", "air_area_name"]).unique(), 
                                            label_df.select(["visit_date", "day_of_week", "holiday_flg", "holiday"]).unique())
            
            date_air_reserve = date_air_reserve.with_columns(
                ((pl.col('weekday') >= 5) | (pl.col('holiday_flg') == 1)).cast(pl.Int8).alias('holiday')
            )
        else:
            # 创建空的DataFrame结构
            date_air_reserve = pl.DataFrame({
                "air_store_id": pl.Series([], dtype=pl.Utf8),
                "visit_date": pl.Series([], dtype=pl.Date),
                "reserve_visitors_sum": pl.Series([], dtype=pl.Int64),
                "reserve_visitors_count": pl.Series([], dtype=pl.Int64),
                "reserve_visitors_mean": pl.Series([], dtype=pl.Float64)
            })
        
        # 添加按weekday聚合的特征
        prefixes = ["air", "hpg"]
        reserve_datasets = [date_air_reserve, date_hpg_reserve]
        
        for prefix, reserve_data in zip(prefixes, reserve_datasets):
            if len(reserve_data) > 0:
                weekday_mean = reserve_data.group_by(["air_store_id", "weekday"]).agg(
                    pl.col("reserve_visitors_sum").mean().alias(f"{prefix}_reserve_visitors_sum_weekday_mean_{i}")
                )
                
                label_df = label_df.join(weekday_mean, on=["air_store_id", "weekday"], how="left")
                label_df = label_df.with_columns(pl.col(f"{prefix}_reserve_visitors_sum_weekday_mean_{i}").fill_null(0))
                
                vis_mean_weekday = reserve_data.group_by(["air_store_id", "weekday"]).agg(
                    pl.col("reserve_visitors_mean").mean().alias(f"{prefix}_reserve_visitors_mean_weekday_mean_{i}")
                )
                
                label_df = label_df.join(vis_mean_weekday, on=["air_store_id", "weekday"], how="left")
                label_df = label_df.with_columns(pl.col(f"{prefix}_reserve_visitors_mean_weekday_mean_{i}").fill_null(0))
                
                count_weekday = reserve_data.group_by(["air_store_id", "weekday"]).agg(
                    pl.col("reserve_visitors_count").mean().alias(f"{prefix}_reserve_visitors_count_weekday_mean_{i}")
                )
                
                label_df = label_df.join(count_weekday, on=["air_store_id", "weekday"], how="left")
                label_df = label_df.with_columns(pl.col(f"{prefix}_reserve_visitors_count_weekday_mean_{i}").fill_null(0))
                
                # 添加按holiday聚合的特征
                holiday_mean = reserve_data.group_by(["air_store_id", "holiday"]).agg(
                    pl.col("reserve_visitors_sum").mean().alias(f"{prefix}_reserve_visitors_sum_holiday_mean_{i}")
                )
                
                label_df = label_df.join(holiday_mean, on=["air_store_id", "holiday"], how="left")
                label_df = label_df.with_columns(pl.col(f"{prefix}_reserve_visitors_sum_holiday_mean_{i}").fill_null(0))
                
                vis_mean_holiday = reserve_data.group_by(["air_store_id", "holiday"]).agg(
                    pl.col("reserve_visitors_mean").mean().alias(f"{prefix}_reserve_visitors_mean_holiday_mean_{i}")
                )
                
                label_df = label_df.join(vis_mean_holiday, on=["air_store_id", "holiday"], how="left")
                label_df = label_df.with_columns(pl.col(f"{prefix}_reserve_visitors_mean_holiday_mean_{i}").fill_null(0))
                
                count_holiday = reserve_data.group_by(["air_store_id", "holiday"]).agg(
                    pl.col("reserve_visitors_count").mean().alias(f"{prefix}_reserve_visitors_count_holiday_mean_{i}")
                )
                
                label_df = label_df.join(count_holiday, on=["air_store_id", "holiday"], how="left")
                label_df = label_df.with_columns(pl.col(f"{prefix}_reserve_visitors_count_holiday_mean_{i}").fill_null(0))
            else:
                # 如果没有数据，填充默认值
                label_df = label_df.with_columns([
                    pl.lit(0.0).alias(f"{prefix}_reserve_visitors_sum_weekday_mean_{i}"),
                    pl.lit(0.0).alias(f"{prefix}_reserve_visitors_mean_weekday_mean_{i}"),
                    pl.lit(0.0).alias(f"{prefix}_reserve_visitors_count_weekday_mean_{i}"),
                    pl.lit(0.0).alias(f"{prefix}_reserve_visitors_sum_holiday_mean_{i}"),
                    pl.lit(0.0).alias(f"{prefix}_reserve_visitors_mean_holiday_mean_{i}"),
                    pl.lit(0.0).alias(f"{prefix}_reserve_visitors_count_holiday_mean_{i}")
                ])
    
    return label_df

