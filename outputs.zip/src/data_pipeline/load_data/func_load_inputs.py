import polars as pl
from pathlib import Path
def load_inputs(input_dir:Path)->dict[str,pl.LazyFrame]:
    datasets_pth = {
        "air_store_info": input_dir / "air_store_info.csv",
        "air_reserve": input_dir / "air_reserve.csv",
        "hpg_store_info": input_dir / "hpg_store_info.csv",
        "hpg_reserve": input_dir / "hpg_reserve.csv",
        "air_visit_data": input_dir / "air_visit_data.csv",
        "date_info": input_dir / "date_info.csv",
        "store_id_relation": input_dir / "store_id_relation.csv",
    }
    datasets = {
        name: pl.scan_csv(pth) for name, pth in datasets_pth.items()
    }
    return datasets
