def merge_reserves(
        
)