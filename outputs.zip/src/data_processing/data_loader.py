import polars as pl
import numpy as np
from datetime import date, timedelta
import os

def load_data(data_dir='../data'):
    """
    加载所有原始数据文件
    
    Returns:
        dict: 包含所有数据表的字典
    """
    # 获取当前脚本所在目录的绝对路径
    current_dir = os.path.dirname(os.path.abspath(__file__))
    # 构建数据目录的绝对路径
    abs_data_dir = os.path.normpath(os.path.join(current_dir, '..', '..', data_dir))
    
    data = {}
    
    # 加载AIR相关数据
    data['air_visit'] = pl.read_csv(os.path.join(abs_data_dir, 'air_visit_data.csv'))
    data['air_reserve'] = pl.read_csv(os.path.join(abs_data_dir, 'air_reserve.csv'))
    data['air_info'] = pl.read_csv(os.path.join(abs_data_dir, 'air_store_info.csv'))
    
    # 加载HPG相关数据
    data['hpg_reserve'] = pl.read_csv(os.path.join(abs_data_dir, 'hpg_reserve.csv'))
    data['hpg_info'] = pl.read_csv(os.path.join(abs_data_dir, 'hpg_store_info.csv'))
    
    # 加载其他数据
    data['date_info'] = pl.read_csv(os.path.join(abs_data_dir, 'date_info.csv'))
    data['store_relation'] = pl.read_csv(os.path.join(abs_data_dir, 'store_id_relation.csv'))
    data['sample_submission'] = pl.read_csv(os.path.join(abs_data_dir, 'sample_submission.csv'))
    
    return data

def preprocess_data(data):
    """
    对原始数据进行预处理
    
    Args:
        data (dict): 原始数据字典
        
    Returns:
        dict: 预处理后的数据字典
    """
    # 对访客数量进行对数变换
    data['air_visit'] = data['air_visit'].with_columns(
        pl.col('visitors').map_elements(
            lambda x: np.log1p(float(x)) if float(x) > 0 else 0
        ).alias('visitors')
    )
    
    # 处理sample_submission，提取air_store_id和visit_date
    data['sample_submission'] = data['sample_submission'].with_columns([
        pl.col('id').map_elements(lambda x: '_'.join(x.split('_')[:2])).alias('air_store_id'),
        pl.col('id').map_elements(lambda x: x.split('_')[2]).alias('visit_date')
    ])
    
    # 处理预订数据的时间信息
    # AIR预订数据
    data['air_reserve'] = data['air_reserve'].with_columns([
        pl.col('reserve_datetime').map_elements(lambda x: x.split(' ')[0]).alias('reserve_date'),
        pl.col('visit_datetime').map_elements(lambda x: x.split(' ')[0]).alias('visit_date')
    ])
    
    data['air_reserve'] = data['air_reserve'].with_columns(
        (pl.col('visit_date').str.strptime(pl.Date, "%Y-%m-%d") - 
         pl.col('reserve_date').str.strptime(pl.Date, "%Y-%m-%d")).dt.total_days().alias('reserve_datetime_diff')
    )
    
    # HPG预订数据
    data['hpg_reserve'] = data['hpg_reserve'].with_columns([
        pl.col('reserve_datetime').map_elements(lambda x: x.split(' ')[0]).alias('reserve_date'),
        pl.col('visit_datetime').map_elements(lambda x: x.split(' ')[0]).alias('visit_date')
    ])
    
    data['hpg_reserve'] = data['hpg_reserve'].with_columns(
        (pl.col('visit_date').str.strptime(pl.Date, "%Y-%m-%d") - 
         pl.col('reserve_date').str.strptime(pl.Date, "%Y-%m-%d")).dt.total_days().alias('reserve_datetime_diff')
    )
    
    # 合并store_relation到air_visit和hpg_reserve
    data['air_visit'] = data['air_visit'].join(
        data['store_relation'], on='air_store_id', how='left'
    )
    data['hpg_reserve'] = data['hpg_reserve'].join(
        data['store_relation'], on='hpg_store_id', how='inner'
    )
    
    # 处理日期信息
    data['date_info'] = data['date_info'].rename({'calendar_date': 'visit_date'})
    weekday_map = {
        'Monday': '1', 'Tuesday': '2', 'Wednesday': '3', 'Thursday': '4', 
        'Friday': '5', 'Saturday': '6', 'Sunday': '7'
    }
    
    # 替换day_of_week列的值
    data['date_info'] = data['date_info'].with_columns([
        pl.col('day_of_week').replace(weekday_map).alias('day_of_week')
    ])
    
    # 转换day_of_week列为整数类型
    data['date_info'] = data['date_info'].with_columns([
        pl.col('day_of_week').cast(pl.Int64).alias('day_of_week')
    ])
    
    data['date_info'] = data['date_info'].with_columns(
        ((pl.col('day_of_week') >= 6) | (pl.col('holiday_flg') == 1)).cast(pl.Int8).alias('holiday')
    )
    
    return data

def merge_reservation_data(data):
    """
    合并AIR和HPG预订数据，生成统一的预订表
    
    Args:
        data (dict): 预处理后的数据字典
        
    Returns:
        tuple: (预测表, 访客表)
    """
    # 获取AIR访问数据中的商店ID列表，用于过滤预订数据
    air_store_ids = data['air_visit'].select('air_store_id').unique()
    
    # 为AIR预订数据添加标识列
    air_reserve_with_flag = data['air_reserve'].with_columns([
        pl.lit(1).alias('is_air_only'),
        pl.lit(None).alias('hpg_store_id')  # 添加空的hpg_store_id列以对齐结构
    ])
    
    # 为HPG预订数据添加标识列，并只保留AIR访问数据中存在的商店
    hpg_reserve_filtered = data['hpg_reserve'].join(
        air_store_ids, on='air_store_id', how='inner'
    )
    
    hpg_reserve_with_flag = hpg_reserve_filtered.with_columns([
        pl.lit(0).alias('is_air_only')
    ])
    
    # 合并AIR和HPG预订数据
    merged_reserve = pl.concat([air_reserve_with_flag, hpg_reserve_with_flag])
    
    # 创建预测表（基于sample_submission）
    prediction_table = data['sample_submission'].clone()
    prediction_table = prediction_table.with_columns([
        pl.lit(1).alias('is_air_only'),  # sample_submission中的都是AIR商店
        pl.lit(None).alias('visitors')   # 预测表没有真实访客数
    ])
    
    # 创建访客表（基于air_visit_data）
    visit_table = data['air_visit'].clone()
    visit_table = visit_table.with_columns([
        pl.lit(1).alias('is_air_only')
    ])
    
    return merged_reserve, prediction_table, visit_table

def split_data_by_time(visit_table, split_date=date(2017, 4, 15)):
    """
    根据时间划分数据集
    
    Args:
        visit_table (DataFrame): 访客表
        split_date (date): 分割日期
        
    Returns:
        tuple: (训练集, 测试集)
    """
    # 计算时间间隔
    visit_table = visit_table.with_columns(
        (pl.col('visit_date').str.strptime(pl.Date, "%Y-%m-%d") - pl.lit(split_date)).dt.total_days().alias('day_gap')
    )
    
    # 划分训练集和测试集
    train_data = visit_table.filter(pl.col('day_gap') < 0)
    test_data = visit_table.filter(pl.col('day_gap') >= 0)
    
    # 添加is_train标记
    train_data = train_data.with_columns(pl.lit(1).alias('is_train'))
    test_data = test_data.with_columns(pl.lit(0).alias('is_train'))
    
    return train_data, test_data