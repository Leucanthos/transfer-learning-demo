import polars as pl
import numpy as np
from datetime import date

def encode_count(df, col):
    """
    对指定列进行计数编码
    
    Args:
        df: 输入DataFrame
        col: 需要编码的列名
        
    Returns:
        编码后的DataFrame
    """
    # 计算每种类别的出现次数
    count_map = df.group_by(col).agg(pl.count().alias(f'{col}_count'))
    
    # 将计数映射回原DataFrame
    df = df.join(count_map, on=col, how='left')
    
    return df

def get_PrEp():
    """
    获取核函数矩阵 (对应solution.py中的Feiyang: 1. 获得核函数 PrEp)
    """
    PrOriginalEp = np.zeros((2000, 2000))
    PrOriginalEp[1, 0] = 1
    PrOriginalEp[2, range(2)] = [0.5, 0.5]
    for i in range(3, 2000):
        scale = (i - 1) / 2.
        x = np.arange(-(i + 1) / 2. + 1, (i + 1) / 2., step=1) / scale
        y = 3. / 4. * (1 - x ** 2)
        y = y / np.sum(y)
        PrOriginalEp[i, range(i)] = y
    PrEp = PrOriginalEp.copy()
    for i in range(3, 2000):
        PrEp[i, :i] = (PrEp[i, :i] * i + 1) / (i + 1)
    return PrEp

def kernel_median(values, PrEp):
    """
    计算核函数中位数 (对应solution.py中的feat_kernelMedian函数)
    """
    values = np.array(values)
    x = values[~np.isnan(values)]
    n = len(x)
    if n == 0:
        return 0
    
    weight = np.repeat(1.0, n)
    idx = np.argsort(x)
    x = x[idx]
    
    if n < PrEp.shape[0]:
        pr = PrEp[n, :n]
    else:
        scale = (n - 1) / 2.
        xxx = np.arange(-(n + 1) / 2. + 1, (n + 1) / 2., step=1) / scale
        yyy = 3. / 4. * (1 - xxx ** 2)
        yyy = yyy / np.sum(yyy)
        pr = (yyy * n + 1) / (n + 1)
    
    ans = np.sum(pr * x * weight) / float(np.sum(pr * weight))
    return ans

def date_handle(df, air_info, date_info, t_begin=date(2017, 4, 15)):
    """
    处理日期特征 (对应solution.py中的date_handle函数)
    
    Args:
        df: 输入DataFrame
        air_info: AIR餐厅信息
        date_info: 日期信息
        t_begin: 分割日期
        
    Returns:
        处理后的DataFrame
    """
    # 先确保visit_date是字符串类型
    df = df.with_columns([
        pl.col('visit_date').cast(pl.Utf8).alias('visit_date')
    ])
    
    df_visit_date = df.with_columns(
        pl.col('visit_date').str.strptime(pl.Date, "%Y-%m-%d").alias('visit_date_parsed')
    )
    
    df = df_visit_date.with_columns([
        df_visit_date['visit_date_parsed'].dt.weekday().alias('weekday'),
        df_visit_date['visit_date_parsed'].dt.day().alias('day')
    ])
    
    # 添加day_gap列
    df = df.with_columns(
        (pl.col('visit_date_parsed') - pl.lit(t_begin)).dt.total_days().alias('day_gap')
    )
    
    # 添加days_to_side特征 (对应solution.py中Feiyang: 2. 新的特征 "days_to_side")
    days_of_months = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    df = df.with_columns(
        pl.struct(['visit_date_parsed']).map_elements(
            lambda row: min(row['visit_date_parsed'].day, 
                           days_of_months[row['visit_date_parsed'].month-1] - row['visit_date_parsed'].day),
            return_dtype=pl.Int32
        ).alias('days_to_side')
    )
    
    # 修改day特征 (对应solution.py中Feiyang: 3. 把月初月末的定义改成了7天)
    df = df.with_columns(
        pl.when(pl.col('day') <= 7)
        .then(0)
        .when(pl.col('day') >= 24)
        .then(2)
        .otherwise(1)
        .alias('day')
    )
    
    # 合并餐厅信息和日期信息
    df = df.join(air_info, on="air_store_id", how="left")
    df = df.join(date_info, on="visit_date", how="left")
    
    return df

def create_features(df_label, df_train, df_air_reserve, df_hpg_reserve, air_info, date_info, PrEp):
    """
    创建特征 (对应solution.py中的create_features函数)
    
    Args:
        df_label: 标签数据
        df_train: 训练数据
        df_air_reserve: AIR预订数据
        df_hpg_reserve: HPG预订数据
        air_info: AIR餐厅信息
        date_info: 日期信息
        PrEp: 核函数矩阵
        
    Returns:
        带特征的DataFrame
    """
    df_train = date_handle(df_train, air_info, date_info)
    df_label = date_handle(df_label, air_info, date_info)
    
    # 预定信息特征
    # AIR预订统计特征 (对应solution.py中Feiyang: 4. 把这两段的 mean 改成了 kernelMedian)
    df_label = df_label.join(
        df_air_reserve.group_by(["air_store_id", "visit_date"]).agg(
            pl.col("reserve_datetime_diff").sum().alias("air_reserve_datetime_diff_sum")
        ), 
        on=["air_store_id", "visit_date"], 
        how="left"
    )
    
    df_label = df_label.with_columns(
        pl.col("air_reserve_datetime_diff_sum").fill_null(0)
    )
    
    # 使用核函数中位数代替均值
    air_res_kernel_median = df_air_reserve.group_by(["air_store_id", "visit_date"]).agg(
        pl.col("reserve_datetime_diff").map_elements(
            lambda x: kernel_median(x, PrEp), 
            return_dtype=pl.Float64
        ).alias("air_reserve_datetime_diff_mean")
    )
    
    df_label = df_label.join(
        air_res_kernel_median, 
        on=["air_store_id", "visit_date"], 
        how="left"
    )
    
    df_label = df_label.with_columns(
        pl.col("air_reserve_datetime_diff_mean").fill_null(0)
    )
    
    # AIR预订访客统计特征
    df_label = df_label.join(
        df_air_reserve.group_by(["air_store_id", "visit_date"]).agg(
            pl.col("reserve_visitors").sum().alias("air_reserve_visitors_sum")
        ), 
        on=["air_store_id", "visit_date"], 
        how="left"
    )
    
    df_label = df_label.with_columns(
        pl.col("air_reserve_visitors_sum").fill_null(0)
    )
    
    # 使用核函数中位数代替均值
    air_res_visitor_kernel_median = df_air_reserve.group_by(["air_store_id", "visit_date"]).agg(
        pl.col("reserve_visitors").map_elements(
            lambda x: kernel_median(x, PrEp), 
            return_dtype=pl.Float64
        ).alias("air_reserve_visitors_mean")
    )
    
    df_label = df_label.join(
        air_res_visitor_kernel_median, 
        on=["air_store_id", "visit_date"], 
        how="left"
    )
    
    df_label = df_label.with_columns(
        pl.col("air_reserve_visitors_mean").fill_null(0)
    )
    
    # 按日期聚合的AIR预订特征
    df_label = df_label.join(
        df_air_reserve.group_by(["visit_date"]).agg(
            pl.col("reserve_visitors").sum().alias("air_date_reserve_visitors_sum")
        ), 
        on=["visit_date"], 
        how="left"
    )
    
    df_label = df_label.with_columns(
        pl.col("air_date_reserve_visitors_sum").fill_null(0)
    )
    
    air_date_visitor_kernel_median = df_air_reserve.group_by(["visit_date"]).agg(
        pl.col("reserve_visitors").map_elements(
            lambda x: kernel_median(x, PrEp), 
            return_dtype=pl.Float64
        ).alias("air_date_reserve_visitors_mean")
    )
    
    df_label = df_label.join(
        air_date_visitor_kernel_median, 
        on=["visit_date"], 
        how="left"
    )
    
    df_label = df_label.with_columns(
        pl.col("air_date_reserve_visitors_mean").fill_null(0)
    )
    
    # HPG预订统计特征
    df_label = df_label.join(
        df_hpg_reserve.group_by(["air_store_id", "visit_date"]).agg(
            pl.col("reserve_datetime_diff").sum().alias("hpg_reserve_datetime_diff_sum")
        ), 
        on=["air_store_id", "visit_date"], 
        how="left"
    )
    
    df_label = df_label.with_columns(
        pl.col("hpg_reserve_datetime_diff_sum").fill_null(0)
    )
    
    # 使用核函数中位数代替均值
    hpg_res_kernel_median = df_hpg_reserve.group_by(["air_store_id", "visit_date"]).agg(
        pl.col("reserve_datetime_diff").map_elements(
            lambda x: kernel_median(x, PrEp), 
            return_dtype=pl.Float64
        ).alias("hpg_reserve_datetime_diff_mean")
    )
    
    df_label = df_label.join(
        hpg_res_kernel_median, 
        on=["air_store_id", "visit_date"], 
        how="left"
    )
    
    df_label = df_label.with_columns(
        pl.col("hpg_reserve_datetime_diff_mean").fill_null(0)
    )
    
    # HPG预订访客统计特征
    df_label = df_label.join(
        df_hpg_reserve.group_by(["air_store_id", "visit_date"]).agg(
            pl.col("reserve_visitors").sum().alias("hpg_reserve_visitors_sum")
        ), 
        on=["air_store_id", "visit_date"], 
        how="left"
    )
    
    df_label = df_label.with_columns(
        pl.col("hpg_reserve_visitors_sum").fill_null(0)
    )
    
    # 使用核函数中位数代替均值
    hpg_res_visitor_kernel_median = df_hpg_reserve.group_by(["air_store_id", "visit_date"]).agg(
        pl.col("reserve_visitors").map_elements(
            lambda x: kernel_median(x, PrEp), 
            return_dtype=pl.Float64
        ).alias("hpg_reserve_visitors_mean")
    )
    
    df_label = df_label.join(
        hpg_res_visitor_kernel_median, 
        on=["air_store_id", "visit_date"], 
        how="left"
    )
    
    df_label = df_label.with_columns(
        pl.col("hpg_reserve_visitors_mean").fill_null(0)
    )
    
    # 按日期聚合的HPG预订特征
    df_label = df_label.join(
        df_hpg_reserve.group_by(["visit_date"]).agg(
            pl.col("reserve_visitors").sum().alias("hpg_date_reserve_visitors_sum")
        ), 
        on=["visit_date"], 
        how="left"
    )
    
    df_label = df_label.with_columns(
        pl.col("hpg_date_reserve_visitors_sum").fill_null(0)
    )
    
    hpg_date_visitor_kernel_median = df_hpg_reserve.group_by(["visit_date"]).agg(
        pl.col("reserve_visitors").map_elements(
            lambda x: kernel_median(x, PrEp), 
            return_dtype=pl.Float64
        ).alias("hpg_date_reserve_visitors_mean")
    )
    
    df_label = df_label.join(
        hpg_date_visitor_kernel_median, 
        on=["visit_date"], 
        how="left"
    )
    
    df_label = df_label.with_columns(
        pl.col("hpg_date_reserve_visitors_mean").fill_null(0)
    )
    
    # 时间窗口特征 (对应solution.py中for i in [35,63,140]循环)
    for i in [35, 63, 140]:
        df_air_reserve_select = df_air_reserve.filter(pl.col('day_gap') >= -i)
        df_hpg_reserve_select = df_hpg_reserve.filter(pl.col('day_gap') >= -i)
        
        # AIR预订聚合
        date_air_reserve = df_air_reserve_select.group_by(["air_store_id", "visit_date"]).agg(
            pl.col("reserve_visitors").sum().alias("reserve_visitors_sum")
        )
        
        date_air_reserve = date_air_reserve.join(
            df_air_reserve_select.group_by(["air_store_id", "visit_date"]).agg(
                pl.col("reserve_visitors").count().alias("reserve_visitors_count")
            ),
            on=["air_store_id", "visit_date"],
            how="left"
        )
        
        air_res_visitors_kernel_median = df_air_reserve_select.group_by(["air_store_id", "visit_date"]).agg(
            pl.col("reserve_visitors").map_elements(
                lambda x: kernel_median(x, PrEp), 
                return_dtype=pl.Float64
            ).alias("reserve_visitors_mean")
        )
        
        date_air_reserve = date_air_reserve.join(
            air_res_visitors_kernel_median,
            on=["air_store_id", "visit_date"],
            how="left"
        )
        
        date_air_reserve = date_handle(date_air_reserve, air_info, date_info)
        date_air_reserve = date_air_reserve.with_columns(
            ((pl.col('weekday') >= 5) | (pl.col('holiday_flg') == 1)).cast(pl.Int8).alias('holiday')
        )
        
        # HPG预订聚合
        date_hpg_reserve = df_hpg_reserve_select.group_by(["air_store_id", "visit_date"]).agg(
            pl.col("reserve_visitors").sum().alias("reserve_visitors_sum")
        )
        
        date_hpg_reserve = date_hpg_reserve.join(
            df_hpg_reserve_select.group_by(["air_store_id", "visit_date"]).agg(
                pl.col("reserve_visitors").count().alias("reserve_visitors_count")
            ),
            on=["air_store_id", "visit_date"],
            how="left"
        )
        
        hpg_res_visitors_kernel_median = df_hpg_reserve_select.group_by(["air_store_id", "visit_date"]).agg(
            pl.col("reserve_visitors").map_elements(
                lambda x: kernel_median(x, PrEp), 
                return_dtype=pl.Float64
            ).alias("reserve_visitors_mean")
        )
        
        date_hpg_reserve = date_hpg_reserve.join(
            hpg_res_visitors_kernel_median,
            on=["air_store_id", "visit_date"],
            how="left"
        )
        
        date_hpg_reserve = date_handle(date_hpg_reserve, air_info, date_info)
        date_hpg_reserve = date_hpg_reserve.with_columns(
            ((pl.col('weekday') >= 5) | (pl.col('holiday_flg') == 1)).cast(pl.Int8).alias('holiday')
        )
        
        # 添加按weekday聚合的特征
        air_weekday_mean = date_air_reserve.group_by(["air_store_id", "weekday"]).agg(
            pl.col("reserve_visitors_sum").mean().alias(f"air_reserve_visitors_sum_weekday_mean_{i}")
        )
        
        df_label = df_label.join(air_weekday_mean, on=["air_store_id", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_reserve_visitors_sum_weekday_mean_{i}").fill_null(0))
        
        hpg_weekday_mean = date_hpg_reserve.group_by(["air_store_id", "weekday"]).agg(
            pl.col("reserve_visitors_sum").mean().alias(f"hpg_reserve_visitors_sum_weekday_mean_{i}")
        )
        
        df_label = df_label.join(hpg_weekday_mean, on=["air_store_id", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"hpg_reserve_visitors_sum_weekday_mean_{i}").fill_null(0))
        
        air_vis_mean_weekday = date_air_reserve.group_by(["air_store_id", "weekday"]).agg(
            pl.col("reserve_visitors_mean").mean().alias(f"air_reserve_visitors_mean_weekday_mean_{i}")
        )
        
        df_label = df_label.join(air_vis_mean_weekday, on=["air_store_id", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_reserve_visitors_mean_weekday_mean_{i}").fill_null(0))
        
        hpg_vis_mean_weekday = date_hpg_reserve.group_by(["air_store_id", "weekday"]).agg(
            pl.col("reserve_visitors_mean").mean().alias(f"hpg_reserve_visitors_mean_weekday_mean_{i}")
        )
        
        df_label = df_label.join(hpg_vis_mean_weekday, on=["air_store_id", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"hpg_reserve_visitors_mean_weekday_mean_{i}").fill_null(0))
        
        air_count_weekday = date_air_reserve.group_by(["air_store_id", "weekday"]).agg(
            pl.col("reserve_visitors_count").mean().alias(f"air_reserve_visitors_count_weekday_mean_{i}")
        )
        
        df_label = df_label.join(air_count_weekday, on=["air_store_id", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_reserve_visitors_count_weekday_mean_{i}").fill_null(0))
        
        hpg_count_weekday = date_hpg_reserve.group_by(["air_store_id", "weekday"]).agg(
            pl.col("reserve_visitors_count").mean().alias(f"hpg_reserve_visitors_count_weekday_mean_{i}")
        )
        
        df_label = df_label.join(hpg_count_weekday, on=["air_store_id", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"hpg_reserve_visitors_count_weekday_mean_{i}").fill_null(0))
        
        # 添加按holiday聚合的特征
        air_holiday_mean = date_air_reserve.group_by(["air_store_id", "holiday"]).agg(
            pl.col("reserve_visitors_sum").mean().alias(f"air_reserve_visitors_sum_holiday_mean_{i}")
        )
        
        df_label = df_label.join(air_holiday_mean, on=["air_store_id", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_reserve_visitors_sum_holiday_mean_{i}").fill_null(0))
        
        hpg_holiday_mean = date_hpg_reserve.group_by(["air_store_id", "holiday"]).agg(
            pl.col("reserve_visitors_sum").mean().alias(f"hpg_reserve_visitors_sum_holiday_mean_{i}")
        )
        
        df_label = df_label.join(hpg_holiday_mean, on=["air_store_id", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"hpg_reserve_visitors_sum_holiday_mean_{i}").fill_null(0))
        
        air_vis_mean_holiday = date_air_reserve.group_by(["air_store_id", "holiday"]).agg(
            pl.col("reserve_visitors_mean").mean().alias(f"air_reserve_visitors_mean_holiday_mean_{i}")
        )
        
        df_label = df_label.join(air_vis_mean_holiday, on=["air_store_id", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_reserve_visitors_mean_holiday_mean_{i}").fill_null(0))
        
        hpg_vis_mean_holiday = date_hpg_reserve.group_by(["air_store_id", "holiday"]).agg(
            pl.col("reserve_visitors_mean").mean().alias(f"hpg_reserve_visitors_mean_holiday_mean_{i}")
        )
        
        df_label = df_label.join(hpg_vis_mean_holiday, on=["air_store_id", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"hpg_reserve_visitors_mean_holiday_mean_{i}").fill_null(0))
        
        air_count_holiday = date_air_reserve.group_by(["air_store_id", "holiday"]).agg(
            pl.col("reserve_visitors_count").mean().alias(f"air_reserve_visitors_count_holiday_mean_{i}")
        )
        
        df_label = df_label.join(air_count_holiday, on=["air_store_id", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_reserve_visitors_count_holiday_mean_{i}").fill_null(0))
        
        hpg_count_holiday = date_hpg_reserve.group_by(["air_store_id", "holiday"]).agg(
            pl.col("reserve_visitors_count").mean().alias(f"hpg_reserve_visitors_count_holiday_mean_{i}")
        )
        
        df_label = df_label.join(hpg_count_holiday, on=["air_store_id", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"hpg_reserve_visitors_count_holiday_mean_{i}").fill_null(0))
    
    # 月初月中月末特征 (对应solution.py中Feiyang: 6. 把这两段的 mean 改成了 kernelMedian)
    air_day_group = df_train.group_by(["air_store_id", "day", "weekday"]).agg(
        pl.col("visitors").map_elements(
            lambda x: kernel_median(x, PrEp), 
            return_dtype=pl.Float64
        ).alias("air_day_mean")
    )
    
    df_label = df_label.join(air_day_group, on=["air_store_id", "day", "weekday"], how="left")
    df_label = df_label.with_columns(pl.col("air_day_mean").fill_null(0))
    
    air_holiday_group = df_train.group_by(["air_store_id", "day", "holiday"]).agg(
        pl.col("visitors").map_elements(
            lambda x: kernel_median(x, PrEp), 
            return_dtype=pl.Float64
        ).alias("air_holiday_mean")
    )
    
    df_label = df_label.join(air_holiday_group, on=["air_store_id", "day", "holiday"], how="left")
    df_label = df_label.with_columns(pl.col("air_holiday_mean").fill_null(0))
    
    # 不同时间窗口的历史访问特征 (对应solution.py中for i in [21,35,63,140,280,350,420]循环)
    for i in [21, 35, 63, 140, 280, 350, 420]:
        df_select = df_train.filter(pl.col('day_gap') >= -i)
        
        # 访客统计特征 (对应solution.py中Feiyang: 7. 给最重要的 visitors 这一列加上了新的特征: kernelMedian, median)
        air_median = df_select.group_by(["air_store_id"]).agg(
            pl.col("visitors").median().alias(f"air_median_{i}")
        )
        
        df_label = df_label.join(air_median, on=["air_store_id"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_median_{i}").fill_null(0))
        
        air_mean = df_select.group_by(["air_store_id"]).agg(
            pl.col("visitors").mean().alias(f"air_mean_{i}")
        )
        
        df_label = df_label.join(air_mean, on=["air_store_id"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_mean_{i}").fill_null(0))
        
        air_kermed = df_select.group_by(["air_store_id"]).agg(
            pl.col("visitors").map_elements(
                lambda x: kernel_median(x, PrEp), 
                return_dtype=pl.Float64
            ).alias(f"air_kermed_{i}")
        )
        
        df_label = df_label.join(air_kermed, on=["air_store_id"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_kermed_{i}").fill_null(0))
        
        air_max = df_select.group_by(["air_store_id"]).agg(
            pl.col("visitors").max().alias(f"air_max_{i}")
        )
        
        df_label = df_label.join(air_max, on=["air_store_id"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_max_{i}").fill_null(0))
        
        air_min = df_select.group_by(["air_store_id"]).agg(
            pl.col("visitors").min().alias(f"air_min_{i}")
        )
        
        df_label = df_label.join(air_min, on=["air_store_id"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_min_{i}").fill_null(0))
        
        air_std = df_select.group_by(["air_store_id"]).agg(
            pl.col("visitors").std().alias(f"air_std_{i}")
        )
        
        df_label = df_label.join(air_std, on=["air_store_id"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_std_{i}").fill_null(0))
        
        air_count = df_select.group_by(["air_store_id"]).agg(
            pl.col("visitors").count().alias(f"air_count_{i}")
        )
        
        df_label = df_label.join(air_count, on=["air_store_id"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_count_{i}").fill_null(0))
        
        # 按weekday聚合的特征 (对应solution.py中Feiyang: 8. 把这几段的 mean 改成了 kernelMedian)
        air_week_kermed = df_select.group_by(["air_store_id", "weekday"]).agg(
            pl.col("visitors").map_elements(
                lambda x: kernel_median(x, PrEp), 
                return_dtype=pl.Float64
            ).alias(f"air_week_kermed_{i}")
        )
        
        df_label = df_label.join(air_week_kermed, on=["air_store_id", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_week_kermed_{i}").fill_null(0))
        
        air_week_max = df_select.group_by(["air_store_id", "weekday"]).agg(
            pl.col("visitors").max().alias(f"air_week_max_{i}")
        )
        
        df_label = df_label.join(air_week_max, on=["air_store_id", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_week_max_{i}").fill_null(0))
        
        air_week_min = df_select.group_by(["air_store_id", "weekday"]).agg(
            pl.col("visitors").min().alias(f"air_week_min_{i}")
        )
        
        df_label = df_label.join(air_week_min, on=["air_store_id", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_week_min_{i}").fill_null(0))
        
        air_week_std = df_select.group_by(["air_store_id", "weekday"]).agg(
            pl.col("visitors").std().alias(f"air_week_std_{i}")
        )
        
        df_label = df_label.join(air_week_std, on=["air_store_id", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_week_std_{i}").fill_null(0))
        
        air_week_count = df_select.group_by(["air_store_id", "weekday"]).agg(
            pl.col("visitors").count().alias(f"air_week_count_{i}")
        )
        
        df_label = df_label.join(air_week_count, on=["air_store_id", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_week_count_{i}").fill_null(0))
        
        # 按holiday聚合的特征
        air_holiday_kermed = df_select.group_by(["air_store_id", "holiday"]).agg(
            pl.col("visitors").map_elements(
                lambda x: kernel_median(x, PrEp), 
                return_dtype=pl.Float64
            ).alias(f"air_holiday_kermed_{i}")
        )
        
        df_label = df_label.join(air_holiday_kermed, on=["air_store_id", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_holiday_kermed_{i}").fill_null(0))
        
        air_holiday_max = df_select.group_by(["air_store_id", "holiday"]).agg(
            pl.col("visitors").max().alias(f"air_holiday_max_{i}")
        )
        
        df_label = df_label.join(air_holiday_max, on=["air_store_id", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_holiday_max_{i}").fill_null(0))
        
        air_holiday_min = df_select.group_by(["air_store_id", "holiday"]).agg(
            pl.col("visitors").min().alias(f"air_holiday_min_{i}")
        )
        
        df_label = df_label.join(air_holiday_min, on=["air_store_id", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_holiday_min_{i}").fill_null(0))
        
        air_holiday_count = df_select.group_by(["air_store_id", "holiday"]).agg(
            pl.col("visitors").count().alias(f"air_holiday_count_{i}")
        )
        
        df_label = df_label.join(air_holiday_count, on=["air_store_id", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_holiday_count_{i}").fill_null(0))
        
        # 按genre和holiday聚合的特征
        genre_holiday_kermed = df_select.group_by(["air_genre_name", "holiday"]).agg(
            pl.col("visitors").map_elements(
                lambda x: kernel_median(x, PrEp), 
                return_dtype=pl.Float64
            ).alias(f"air_genre_name_holiday_kermed_{i}")
        )
        
        df_label = df_label.join(genre_holiday_kermed, on=["air_genre_name", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_genre_name_holiday_kermed_{i}").fill_null(0))
        
        genre_holiday_max = df_select.group_by(["air_genre_name", "holiday"]).agg(
            pl.col("visitors").max().alias(f"air_genre_name_holiday_max_{i}")
        )
        
        df_label = df_label.join(genre_holiday_max, on=["air_genre_name", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_genre_name_holiday_max_{i}").fill_null(0))
        
        genre_holiday_min = df_select.group_by(["air_genre_name", "holiday"]).agg(
            pl.col("visitors").min().alias(f"air_genre_name_holiday_min_{i}")
        )
        
        df_label = df_label.join(genre_holiday_min, on=["air_genre_name", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_genre_name_holiday_min_{i}").fill_null(0))
        
        genre_holiday_count = df_select.group_by(["air_genre_name", "holiday"]).agg(
            pl.col("visitors").count().alias(f"air_genre_name_holiday_count_{i}")
        )
        
        df_label = df_label.join(genre_holiday_count, on=["air_genre_name", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_genre_name_holiday_count_{i}").fill_null(0))
        
        # 按genre和weekday聚合的特征
        genre_weekday_kermed = df_select.group_by(["air_genre_name", "weekday"]).agg(
            pl.col("visitors").map_elements(
                lambda x: kernel_median(x, PrEp), 
                return_dtype=pl.Float64
            ).alias(f"air_genre_name_weekday_kermed_{i}")
        )
        
        df_label = df_label.join(genre_weekday_kermed, on=["air_genre_name", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_genre_name_weekday_kermed_{i}").fill_null(0))
        
        genre_weekday_max = df_select.group_by(["air_genre_name", "weekday"]).agg(
            pl.col("visitors").max().alias(f"air_genre_name_weekday_max_{i}")
        )
        
        df_label = df_label.join(genre_weekday_max, on=["air_genre_name", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_genre_name_weekday_max_{i}").fill_null(0))
        
        genre_weekday_min = df_select.group_by(["air_genre_name", "weekday"]).agg(
            pl.col("visitors").min().alias(f"air_genre_name_weekday_min_{i}")
        )
        
        df_label = df_label.join(genre_weekday_min, on=["air_genre_name", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_genre_name_weekday_min_{i}").fill_null(0))
        
        genre_weekday_count = df_select.group_by(["air_genre_name", "weekday"]).agg(
            pl.col("visitors").count().alias(f"air_genre_name_weekday_count_{i}")
        )
        
        df_label = df_label.join(genre_weekday_count, on=["air_genre_name", "weekday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_genre_name_weekday_count_{i}").fill_null(0))
        
        # 按area和holiday聚合的特征
        area_holiday_kermed = df_select.group_by(["air_area_name", "holiday"]).agg(
            pl.col("visitors").map_elements(
                lambda x: kernel_median(x, PrEp), 
                return_dtype=pl.Float64
            ).alias(f"air_area_name_holiday_kermed_{i}")
        )
        
        df_label = df_label.join(area_holiday_kermed, on=["air_area_name", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_area_name_holiday_kermed_{i}").fill_null(0))
        
        area_holiday_max = df_select.group_by(["air_area_name", "holiday"]).agg(
            pl.col("visitors").max().alias(f"air_area_name_holiday_max_{i}")
        )
        
        df_label = df_label.join(area_holiday_max, on=["air_area_name", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_area_name_holiday_max_{i}").fill_null(0))
        
        area_holiday_min = df_select.group_by(["air_area_name", "holiday"]).agg(
            pl.col("visitors").min().alias(f"air_area_name_holiday_min_{i}")
        )
        
        df_label = df_label.join(area_holiday_min, on=["air_area_name", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_area_name_holiday_min_{i}").fill_null(0))
        
        area_holiday_count = df_select.group_by(["air_area_name", "holiday"]).agg(
            pl.col("visitors").count().alias(f"air_area_name_holiday_count_{i}")
        )
        
        df_label = df_label.join(area_holiday_count, on=["air_area_name", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_area_name_holiday_count_{i}").fill_null(0))
        
        # 按area、genre和holiday聚合的特征
        area_genre_holiday_kermed = df_select.group_by(["air_area_name", "air_genre_name", "holiday"]).agg(
            pl.col("visitors").map_elements(
                lambda x: kernel_median(x, PrEp), 
                return_dtype=pl.Float64
            ).alias(f"air_area_genre_name_holiday_kermed_{i}")
        )
        
        df_label = df_label.join(area_genre_holiday_kermed, on=["air_area_name", "air_genre_name", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_area_genre_name_holiday_kermed_{i}").fill_null(0))
        
        area_genre_holiday_max = df_select.group_by(["air_area_name", "air_genre_name", "holiday"]).agg(
            pl.col("visitors").max().alias(f"air_area_genre_name_holiday_max_{i}")
        )
        
        df_label = df_label.join(area_genre_holiday_max, on=["air_area_name", "air_genre_name", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_area_genre_name_holiday_max_{i}").fill_null(0))
        
        area_genre_holiday_min = df_select.group_by(["air_area_name", "air_genre_name", "holiday"]).agg(
            pl.col("visitors").min().alias(f"air_area_genre_name_holiday_min_{i}")
        )
        
        df_label = df_label.join(area_genre_holiday_min, on=["air_area_name", "air_genre_name", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_area_genre_name_holiday_min_{i}").fill_null(0))
        
        area_genre_holiday_count = df_select.group_by(["air_area_name", "air_genre_name", "holiday"]).agg(
            pl.col("visitors").count().alias(f"air_area_genre_name_holiday_count_{i}")
        )
        
        df_label = df_label.join(area_genre_holiday_count, on=["air_area_name", "air_genre_name", "holiday"], how="left")
        df_label = df_label.with_columns(pl.col(f"air_area_genre_name_holiday_count_{i}").fill_null(0))
        
    return df_label